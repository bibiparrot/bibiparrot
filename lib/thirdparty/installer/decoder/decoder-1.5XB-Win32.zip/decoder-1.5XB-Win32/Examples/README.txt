To try out this examples you need to have "decoder.py", installed in your Python site-packages directory
or placed in the same directory with the examples.
Example 'miniplayer.py' also depends on PyAudio library.